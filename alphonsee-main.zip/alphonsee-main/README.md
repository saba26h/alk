## Alphonse Future Engineers

At this repository you can see all files of our documentation. you can Look at the documentation and open files to see robot's photos, team photo, and etc.

## Content

* the folder `t-photos` contains 2 funny photos of the team and an official one . 
* the folder `v-photos` contains 6 photos of the vehicle from every side.
* the folder `video` contains the video.md file which has a link to a Youtube Video showing a whole run of the Robot.
* the folder `schemes` contains a diagrams of the all the elements used in the vehicle and how they connect to each other.
* the folder `src` contains code of control software for all components which were programmed to participate in the competition
* the folder `components` contains photos of the components used in the vehicle.





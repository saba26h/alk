Team's photos
====

This directory contains 2 funny photos of the team and an official one.

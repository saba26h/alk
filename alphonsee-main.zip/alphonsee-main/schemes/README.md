Electromechanical diagrams
====

This directory contains a diagram of the electromechanical components illustrating all the elements.

Control software
====

This directory contains code for control software which is used by the vehicle to participate in the competition and which was developed by the participants.


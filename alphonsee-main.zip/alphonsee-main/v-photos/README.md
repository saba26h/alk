 Vehicle's photos
====

This directory contains 6 photos the first vehicle we used and 6 for our vehicle now (valkiry) from every side.
